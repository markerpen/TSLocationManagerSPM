//
//  LogQuery.h
//  TSLocationManager
//
//  Created by Christopher Scott on 2019-10-22.
//  Copyright © 2019 Transistor Software. All rights reserved.
//

#import "SQLQuery.h"

@interface LogQuery:SQLQuery

@end
